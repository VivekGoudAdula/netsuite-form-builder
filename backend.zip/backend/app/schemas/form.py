from pydantic import BaseModel, Field, validator
from typing import List, Optional, Any, Dict
from datetime import datetime

class FieldLayoutSchema(BaseModel):
    columnBreak: bool = False
    spaceBefore: bool = False
    order: int = 0

class APIConfigSchema(BaseModel):
    url: str
    method: str = "GET"
    labelKey: str = "name"
    valueKey: str = "id"

class FieldOptionSchema(BaseModel):
    label: str
    value: str

class DataSourceSchema(BaseModel):
    type: str  # "static" or "api"
    options: Optional[List[FieldOptionSchema]] = None
    apiConfig: Optional[APIConfigSchema] = None

class FieldSchema(BaseModel):
    fieldId: str
    label: str
    visible: bool = True
    mandatory: bool = False
    displayType: str = "normal"
    checkBoxDefault: str = "default"
    type: str = "string"
    section: str = "body"
    subSection: Optional[str] = None
    group: Optional[str] = None
    tab: Optional[str] = None
    layout: FieldLayoutSchema = FieldLayoutSchema()
    dataSource: Optional[DataSourceSchema] = None

class FieldGroupSchema(BaseModel):
    id: str
    name: str
    order: int = 0
    fields: List[FieldSchema] = []

class TabSchema(BaseModel):
    id: Optional[str] = None
    name: str
    visible: bool = True
    fieldGroups: List[FieldGroupSchema] = []
    itemSublist: Optional[List[FieldSchema]] = []
    expenseSublist: Optional[List[FieldSchema]] = []

class FormStructure(BaseModel):
    tabs: List[TabSchema] = []

class FormBase(BaseModel):
    name: str
    companyId: str
    transactionType: str
    assignedTo: List[str] = []
    structure: FormStructure

class FormCreate(FormBase):
    pass

class FormUpdate(BaseModel):
    name: Optional[str] = None
    structure: Optional[FormStructure] = None

class CloneFormRequest(BaseModel):
    targetCompanyId: Optional[str] = None
    newName: str

class AssignUsersRequest(BaseModel):
    userIds: List[str]

class MyFormResponse(BaseModel):
    id: str
    name: str
    transactionType: str
    lastUsed: str = "Never"
    updatedAt: Optional[str] = None

class FormSubmissionRequest(BaseModel):
    values: Dict[str, Any]

class FormResponse(FormBase):
    id: str
    createdBy: str
    createdAt: datetime
    updatedAt: datetime

    class Config:
        from_attributes = True
